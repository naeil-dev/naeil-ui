# naeil UI v2 — Design brief

Use a neutral palette, Pretendard, larger text, purpose-specific widths, comfortable spacing by default, compact spacing for dense views, and short restrained transitions respecting reduced motion. See [the v2 specification](https://github.com/naeil-dev/naeil-ui/blob/main/docs/superpowers/specs/2026-09-29-shared-ui-v2-design.md) for scope and [STATUS.md](https://github.com/naeil-dev/naeil-ui/blob/main/STATUS.md#current-state) for current status.

## Purpose and scope

Build a shared design system that gives naeil products a precise, calm, coherent interface. The deliverables are design rules, tokens, reusable React components, composition examples, and instructions for consumers and coding agents.

The design must work for settings, forms, lists, and information panels across products. naeil.dev page composition, project illustrations, hero scenes, and other site content are outside this brief. Existing brand components in the public package require an explicit migration decision before their API changes.

## Reference and provenance

- Structural reference: Linear.
- Source: https://github.com/VoltAgent/awesome-design-md/blob/main/design-md/linear.app/DESIGN.md
- Workflow reference: https://www.threads.com/@automation_claire/post/Dd1GZoREhnt
- Follow-up constraints: https://www.threads.com/@automation_claire/post/Dd1GcQGkpbL

The source is a third-party analysis of Linear's marketing pages, not an official specification of Linear's application. Its light theme, form validation, and complete application state palette are not documented. Source values are reference material, not verified accessibility results.

Adopt from the reference:

- Neutral surfaces with a slight cool tint and a consistent hierarchy of surface levels.
- A restrained accent for important actions, selection, links, and focus.
- Fine borders and surface differences to establish grouping and depth.
- Medium and semibold typography with explicit roles.
- A 4px spacing foundation and role-specific corner radii.

Adapt for naeil:

- Support both light and dark modes; the source's dark-only marketing rule does not apply.
- Use available fonts with Korean, Japanese, and Latin coverage, rather than Linear's proprietary fonts.
- Define success, warning, error, information, loading, empty, disabled, and selected states for product workflows.
- Establish product UI sizes rather than adopting marketing display sizes and section spacing.
- Keep the accent replaceable through a documented, accessible theme contract.

## Visual direction

Precision comes from consistent alignment, spacing, hierarchy, and interaction states. Group related information through proximity and separators; use a panel when it represents a meaningful group. Give the main task the strongest visual emphasis.

Use restrained rounding and quiet surface treatments. Gradients, glow, backdrop blur, and animated decoration are not default component treatments. Motion should communicate a state change or spatial relationship.

## Selected visual foundation

Use the neutral palette, larger text, Pretendard, purpose-specific content widths, comfortable spacing, complete interaction states and short transitions. Engineering and compatibility rules are in the linked specification. These are naeil rules, not assertions about Linear's product UI.

### Color and surfaces

Define semantic roles before choosing final palette values:

| Role | Purpose |
| --- | --- |
| canvas | Application background |
| surface | Grouped content and panels |
| surface-raised | Menus, popovers, dialogs |
| surface-hover | Pointer hover on interactive surfaces |
| surface-selected | Persistent selection, distinct from hover |
| text-primary / secondary / disabled | Text hierarchy with explicit use restrictions |
| border / border-strong | Group boundaries and control boundaries |
| action / action-hover / action-pressed / on-action | Primary action colors |
| focus | Keyboard focus indicator |
| success / warning / error / info | Feedback, each with text and subtle-surface companions |

Use `text-error` / `bg-error-bg` / `border-error` for error feedback; reserve `destructive` / `destructive-foreground` for filled dangerous-action pairs, never `text-destructive` for error copy on canvas/card (insufficient dark-mode contrast).

Use neutral surfaces, neutral selection backgrounds, and a neutral action palette as the shared default. Purple, blue and teal are not shared action themes. Provide complete light/dark roles and validate actual text and control states before publishing.

Brand/action, muted surface, and focus are separate semantic decisions even when some share a color. A project accent override must include its foreground and interaction states; replacing a single hue must not silently break legibility.

Normal text must meet 4.5:1 contrast, large text 3:1, and essential control boundaries and state indicators 3:1 against adjacent colors. Validate rendered combinations, including opacity. Decorative separators need not be treated as control boundaries. Disabled styles must not be reused for readable metadata.

### Typography

UI family: Pretendard for Korean and for Latin letters and digits in every language, with Noto Sans JP for Japanese glyphs (see the screen frame contract). No shared monospace family is prescribed. Font delivery follows the screen frame contract. Verify all three languages in specimens.

| Role | Size / line height | Weight |
| --- | --- | --- |
| Page title | 32 / 42px | 600 |
| Section title | 20 / 29px | 600 |
| Component title | 16 / 25px | 600 |
| UI body | 16 / 25px | 400 |
| Reading body | 16 / 30px | 400 |
| Label and control | 16 / 25px | 500 |
| Supporting text | 14 / 22px | 400 |
| Metadata | 13 / 20px | 400 |

Do not tighten body letter spacing to imitate a marketing headline. Metadata remains readable. Form labels, errors, and essential information must not shrink to badge-sized text. Preserve mobile input sizing where needed to avoid browser auto-zoom.

### Size, spacing, and shape

- Foundation: 4, 8, 12, 16, 24, 32, 48, 64px; allow named 2px optical adjustments for icons and indicators.
- Default control height: 40px. Compact control height: 36px, for deliberate dense layouts. Touch interaction areas: at least 44px, without overlapping adjacent targets.
- Default form/panel padding: 24px; compact form padding: 20px. Use 8px within a field and 24px between field groups, reduced to 16px in compact forms. Explicitly small surfaces may use 16px padding.
- Small tags: 4px radius. Buttons and inputs: 8px. Panels and dialogs: 12px. Circular avatars remain circular.
- Layout density must be consistent within a control group; individual consumers should not invent independent padding scales.

### Motion

Use named fast (120ms) and standard (180ms) transitions for color and opacity, with at most a small movement for notifications. Reduced-motion mode removes transitions and spatial movement. Do not add default spring, bounce, magnetic, or decorative motion.

## Components and composition

First implement the foundation and existing eight families: Button, Input, Card, Dialog, DropdownMenu, Badge, Avatar, and Toaster. Align shared title primitives and theme controls with the same foundation.

- Button: clear primary/secondary/quiet/destructive hierarchy; specified hover, pressed, focus, disabled, and loading behavior.
- Input: visible field boundaries, label/help/error composition, and clear focus/invalid states.
- Card: grouping and surface role, without implying that every content block needs a card. Distinguish static and interactive examples.
- Dialog and menu: coherent raised surfaces, keyboard interaction, visible focus, and appropriate dismissal behavior.
- Badge and toast: status meaning conveyed by text or icon as well as color.
- Avatar: readable fallback initials; imagery supplied by the consumer.

Demonstrate the system in three neutral compositions: a settings form, a selectable list with metadata, and a detail panel with actions. These are library examples, not a redesign of a particular website. Additional public components require a demonstrated composition need.

### Owned-service header rule

Owned services set `NaeilServiceShell service="storm" | "home" | "estimate" | "jev"` (`abstorm` remains accepted until that service has moved to `storm`); the shell passes that id to the shared header/footer. The left brand is logo → `.naeil` → lowercase service id, with no status dot or extra indicator; naeil.dev has no service suffix. The service supplies only its own `header.appNavigation` tabs. The DS owns their shape, placement, sizes, spacing and default/hover/selected/expanded/mobile states; service style or slot overrides are not allowed. Projects/Blog belong only to naeil.dev. A single-screen service leaves the center empty; its mobile menu still exposes theme/locale/account. The right toolbar is unchanged. Standalone `NaeilHeader` service profiles remain compatible; the no-service catalog API and rendered output are preserved for naeil.dev and existing consumers.

The service-header branch rejects `brandSuffix`, `statusSlot`, `brandSlot`, `toolbarSlot`, `subNav`, `brandLinkComponent`, `projects`, `projectsExternal`, `showProjects`, `showBlog`, `translations`, `className`, `containerClassName`, `style`, `brandLinkProps`, `mobileFooter` and `omitEmptyNavigation`; runtime attempts are ignored. Header `data-slot`, `data-global-header` and `data-naeil-*` markers are protected. Under the shell, the header element is shell-owned: services pass only `appNavigation`, `currentHref`, `brandHref`, `authSlot`, `labels`, `resolveHref`, `onLocaleChange`, `mobileOpen` and `onMobileOpenChange`. Navigation `labels` supplies accessible names; header `id`/`aria-*`/`dir` attributes are not shell inputs. Standalone `NaeilHeader` retains its `id`/`aria-*`/`dir` semantics for non-shell compositions; the shell's own main id/classes are fixed. Routing adapters and auth state remain consumer-owned and must not be used for styling shared chrome; owned-service account presentation comes from shell `account`. `header.authSlot` remains deprecated compatibility and loses to account when both are supplied.

### Application frame and content widths

Use a shared maximum application frame of **1600px**, with responsive inline gutters **clamp(16px, 2.4vw, 40px)**. The frame includes its padding, centers on wider screens and shrinks to available space. Numeric values live in `ui.width-frame` and `ui.frame-gutter`; `.ui-app-frame`, `Navigation`, `SiteFooter`, `NaeilHeader`, and the legacy adapters use those same defaults.

The page root reserves scrollbar space. Shared full-page frames use `html { scrollbar-gutter: stable; }`, with one scrollbar-side gutter in classic mode and no reserved space in overlay mode. Header, main and footer use the resulting available page width. Changing page length or opening and closing a scroll-locking surface MUST NOT move those frames or their content horizontally. A consumer using a different document scroll policy MUST declare the documented root opt-out and own that policy consistently across routes.

The package implements this default once in `components.css`, through either `globals.css` or `theme.css + components.css`. Theme-only/JS-only imports do not set it. `<html data-naeil-scrollbar-gutter="auto">` opts out of both the root reservation and its Radix duplicate-compensation correction before first paint. The default profile is LTR with zero body edge spacing; custom scrollers, body margins or dependency helper classes require consumer integration/opt-out. Unsupported browsers retain existing scroll-lock compensation. See the [adopted frame contract](https://github.com/naeil-dev/naeil-ui/blob/434b7d07235316097ca3a55265ee02c1422b0cfd/docs/superpowers/specs/2026-10-29-page-root-scrollbar-gutter.md) and [consumer override guidance](docs/components/application-layout.md).

The optional `@naeil/ui/naeil-header` composition centralizes the actual naeil.dev brand/catalog/control/toolbar/responsive implementation. Official decorative image URLs remain references; no new artwork rights or redistribution is implied. See [NaeilHeader](docs/components/naeil-header.md).

Owned naeil services use `NaeilServiceShell` with root `NaeilThemeProvider`, supplying product menu data through `header.appNavigation`. The shell composes the canonical header/main/footer; services own menu data, route guards, locale and authentication through adapters and slots. naeil.dev is rendered through the same shell with its catalog header/footer (see the screen frame contract below). Generic `Navigation`/`SiteFooter` remain for a different product without canonical naeil chrome; standalone header/footer and existing `Nav`/`Footer` preserve their compatibility APIs. Extend the shared API when a reusable behavior is missing instead of copying menu, responsive or footer implementations. See [the application starter and consumer-agent rules](docs/components/application-layout.md).

Owned Next services under the shared locale provider import shell/provider/PageHeader/account chrome from `@naeil/ui/naeil-locale/chrome`; standalone React services use `/naeil-shell` with its account prop for account presentation. `/naeil-header` and `/naeil-footer` remain standalone React adapters (see [the locale runtime](docs/components/naeil-locale.md)).

The application frame owns navigation placement and outer gutters; each content region owns its purpose-specific width. A narrow settings form inside that frame must not move the shared navigation. For routes using the same frame, keep navigation anchors stable at the same viewport, language and theme, including loading and changing summary counts. A shared Header import alone does not establish this consistency.

Content caps are reading **640px**, settings **640px**, short form **480px**, lists **1600px**, and workflow **896px** (`ui.width-workflow`, `data-ui-layout="workflow"`) for multi-step or card-choice input screens. Individual fields and helper text inside a workflow still follow the 640/480px caps. Owned services put purpose-specific content inside the shell's main without adding frame classes; generic compositions apply `.ui-app-frame` to their main. Lists, tables and dashboards use the space remaining after frame gutters, while narrow reading/forms stay inside that stable outer frame. `data-ui-layout="fluid"` uses the available region. At a 1920px viewport the default frame has 1520px of usable width.

Generic/legacy compositions may deliberately override `--ui-width-frame`, `--ui-frame-gutter`, content tokens or supported `containerClassName`; apply frame overrides consistently to header, main and footer. Choose exceptions from representative tasks and sparse/dense content, and record the reason. These compatibility overrides do not apply to the owned-service shell, including through ancestors or reserved selectors; owned services keep purpose-specific widths inside main. An override is not permission to fork shared chrome. Generic/legacy compositions can keep the old list cap with `--ui-width-list: 1200px` where required.

### Page rhythm, theme and base text

naeil.dev and every owned service share the same frame, theme, base text and page rhythm outside their purpose-specific content:

- Owned services use `NaeilServiceShell` + root `NaeilThemeProvider`; CI runs both static and runtime `naeil-ui-conformance` checks. Services supply session state through shell `account`; the shell owns localized login/account presentation with its locale/Link. Signed-out pages show login except when loginHref/currentHref pathnames match; record that screen with runtime `--no-account`. Static CI requires account= and rejects deprecated shell header.authSlot. Do not reconstruct the main frame, theme policy, base text or favicon declarations from written rules. See [the shell contract](docs/components/naeil-shell.md).
- The shell owns main's `.ui-app-frame ui-app-main`: fixed-header clearance, `ui.page-top` 48px and `ui.page-bottom` 96px. App source adds no frame classes or independent top/bottom page padding.
- Pages start with `PageHeader`: 32/42 semibold at every width, `ui.page-title-gap` 12px, 16/25 secondary description capped at reading width, end-aligned actions, `ui.page-header-gap` 32px before content.
- Shared CSS supplies 16px Pretendard base text. The root provider supplies the dark default, remembered theme and system option. Generated `naeilIcons` supplies the exact brand-file digests and naeil.dev icon declarations; the conformance CLI rejects divergence.

Horizontal content widths remain purpose-specific (reading/settings 640px, forms 480px, lists 1600px). Verify with screenshots of matching routes, not only DOM attributes.

### Screen frame contract

This section is authoritative where an earlier paragraph or a dated specification disagrees. It applies to naeil.dev and every owned service alike; naeil.dev is rendered through the same shell.

**Frame.** `NaeilServiceShell` renders one frame element around skip link, header, main and footer. The frame is at least one viewport tall (`100dvh`) and lays out in a column; main takes the remaining height.
- Short page: the footer's bottom edge sits on the viewport's bottom edge. No blank canvas appears below the footer.
- Long page: the footer follows the content, with the existing 96px (`ui.page-bottom`) between the end of content and the footer.
- A recorded no-footer screen (`footer={false}`, e.g. Home login) still fills the viewport with main.
- Applications add no `min-height`, flex or wrapper of their own to achieve this.

**Fonts.** The package delivers its fonts through one entry, `@naeil/ui/fonts.css`. Applications import that entry and do not install or import Pretendard or Noto Sans JP themselves.
- Latin letters and digits (U+0020–007E, U+00A0–00FF) render in Pretendard in every language, including inside Japanese text and Japanese chrome.
- Kana, kanji and Japanese punctuation render in Noto Sans JP. Korean renders in Pretendard.
- A page that needs no Japanese glyphs downloads no Japanese font file, and at most one Japanese font stylesheet.

**Theme preference.** An explicit shared theme-control choice (`light`, `dark` or `system`) is remembered across HTTPS naeil.dev sites in the first-party `naeil_theme_v1` cookie (`Domain=naeil.dev`, Path=/, Secure, SameSite=Lax, one year). A valid shared value wins over origin-local `theme` storage. For the first painted background, including blank streamed frames, put the shared server-safe `NaeilThemeScript` (`@naeil/ui/theme-bootstrap`) in the root head outside Suspense; Vite injects `naeilThemeBootstrap` with head-prepend. Keep the root provider for interactive state. Body/provider scripts alone do not guarantee pre-content paint timing. Without it, the remembered local value wins, then dark; old local values never create the shared cookie. Other hosts use a host-only cookie. Home uses a different registrable host and keeps its own choice; no cross-domain synchronization is provided. Storage denial retains the dark default; cookie denial retains local persistence.

**Base text.** Shared CSS sets the body baseline — semantic background and foreground, the font stack above and 16/25px text — identically whether an application imports `globals.css` or `theme.css` + `components.css`. Applications do not restate body colour, font or line height. Chrome typography values are generated from the token source, not maintained beside it.

**Icons.** `/favicon.ico`, `/icon.svg` and `/apple-icon.png` return 200 with the current brand kit's bytes at every address users actually open, including reverse-proxied and private-network addresses. A declaration in metadata is not sufficient; the response is the requirement.

**Error and not-found screens.** They use the same frame: header, main and footer, the remembered or default dark theme, the shared fonts and a link back. Error documents generated outside React (the locale layer's fallback document) carry at least the dark colours, the shared font stack and their home links. naeil.dev has a localized not-found screen.

**Signed-in state.** The same frame, fonts and rhythm hold when signed in. The header shows the shell's account control: visible in the toolbar at desktop width, inside the menu at mobile width. Signed-out pages show the login control except on the login route itself.

**Acceptance.** "Matching" is claimed only from a comparison of the addresses users actually open — naeil.dev and the four services, Home through its private-network address — across ko/ja/en, 1440 and 390px widths, and a short and a long page, with zero differences in: footer-to-viewport gap, rendered fonts, body text metrics, icon responses, title format, first-visit theme and header/footer pixels. Conformance checks, hashes, fixtures and loopback runs are supporting evidence only. A report states address, language, width, sign-in state and browser, and writes "not measured" for anything it did not measure. A comparison must not mask a region as "intended" unless this contract names it as service-owned (service suffix, app navigation, account state).

Internal columns must respond to the space available inside their region. Use container queries or an equivalent content-aware layout when viewport breakpoints no longer represent that space. Keep wide tables locally scrollable; check localized labels, wrapping and controls inside cells as well as page overflow. See the [consumer composition guide](docs/design/v2-migration.md#앱-전체-틀과-콘텐츠-폭) for application ownership and checks.

## Connection to implementation

Use one canonical token source to generate the CSS that the package actually exports and that contrast checks inspect. Wire typography, radii, spacing, elevation, and motion into that same system. The visual design brief explains roles; numeric implementation values must be synchronized with the token source.

Preserve Radix interaction behavior and the existing React/Tailwind integration unless a concrete requirement warrants a change. Inventory current public exports before migration. Existing Nav, Footer, Logo, project colors, and deep import contracts need explicit compatibility decisions; do not silently remove them during a visual pass.

Consumer and repository agent guidance must explicitly point to this design document and the component APIs. External examples may fill an identified gap, and their adopted rules or code must be attributed. No custom skill or plugin is required to deliver v2. Installing a tool is a separate decision from selecting a design reference.

## Evaluation and acceptance

Compare the same compositions and content in light/dark themes, desktop/mobile widths, and Korean/Japanese/English. Include long labels, multiline content, keyboard focus, errors, disabled controls, and loading examples.

Before release, verify generated token consistency, public-package consumption, component behavior and accessibility, and visual results. Review actual screenshots or a working preview; a token table alone does not establish visual quality.

For application layout changes, compare affected routes side by side under the same conditions and verify the frame invariants separately from each page's component checks. Record functional checks, shared-design compliance and visual composition as distinct results. Keep prior findings open until remeasured or explicitly scoped out; a layout review does not close unrelated contrast, nested-control or touch findings.


## Brand assets and shared components

The approved naeil sunset/island identity is managed independently under `brand/naeil/1.1.1/`. The standalone SVG/PNG/favicon kit is usable without React or this UI package. Its version is separate from the npm version; released brand directories are immutable. New artwork requires a new reviewed brand version. The official wordmark is `.naeil`; its leading period means an ending followed by tomorrow. Keep the period in outlined lettering; standalone symbols need no extra dot.

The shared `Logo` is the React adapter for that source. `brand/current.json` selects the active release for generation, Storybook and consumer checks. `pnpm build:brand` generates `src/components/brand-artwork.generated.tsx`, the Lato notice and app-owned site icons from checksum-verified release files; do not hand-edit the generated artwork. `pnpm check:brand` checks drift and runs before package/Storybook builds. Nav, Footer and the website login use the shared Logo instead of maintaining inline copies. Consumer brand slots remain supported.

Lato Regular 400 is outlined lettering inside the logo only. It does not replace Pretendard, add a webfont dependency or turn the sunset palette into shared action tokens. Logo sizes and placement remain brand guidance, not numeric UI foundation tokens. See the [brand component contract](docs/design/v2-migration.md#brand-logo-integration-040) for themes, sizing, legacy mono behavior and accessibility. The standalone kit, research artifacts and high-resolution PNGs stay out of the npm package; generated artwork and the [Lato notice](licenses/Lato-OFL.txt) ship with the component. Brand names/marks are not relicensed by the repository MIT license.

## Browser identity — tab title and favicon

Browser identity is part of the shared brand/content contract. The browser owns tab typography and sizing; this is a metadata rule, not a visual component or numeric token.

- Use `Page name — Service name` for named pages, with one space on each side of the em dash. Put the page first so tabs remain distinguishable when titles are truncated.
- A service home/landing page may use the service name alone. A named task screen such as a dashboard keeps its page name, even when it is the application's entry route.
- The service name matches the header brand: `.naeil` for naeil.dev and `.naeil <service>` for owned services (`.naeil home`, `.naeil estimate`, `.naeil storm`, `.naeil jev`). The shared package derives it from the service id (`localeMetadata`, `naeilDocumentTitle`); applications do not pass their own service string. The leading period is part of the official brand spelling.
- Localize the page name with the active UI language; keep the canonical service name unchanged. Use the visible page name or content title, and append the service suffix exactly once.
- naeil.dev and every owned service use the same `.naeil` favicon from the current brand kit (`brand/naeil/1.1.1/icons/`: `favicon.ico`, `favicon.svg`, `apple-touch-icon.png`) on every route. Each service copies those unmodified files into its app and owns their serving, metadata/manifest configuration and deployment; the kit stays out of the npm package.
- Each application implements the title through its framework metadata or router and updates it on client-side navigation and language changes. Shared Navigation/Logo components do not set document metadata implicitly.

Examples: `.naeil home`, `대시보드 — .naeil home`, `API 키 — .naeil home`, `프로젝트 — .naeil`, `見積 — .naeil estimate`, `New review — .naeil storm`.

The owned-service shell renders the full `NaeilFooter` with its `service` id and no density, class, style or attribute overrides. Its brand is `.naeil` alone; the tagline and naeil.dev Projects/Blog/GitHub destinations stay. The shell's `footer` prop accepts only `meta`/`resolveHref`, or `false` for a recorded no-footer screen such as Home login; main and skip link remain. Owned services leave `meta` empty and render no meta row; app versions and product status belong in application settings or content. The public `meta` API remains available for standalone/generic compositions and existing consumers. See [consumer implementation and verification guidance](docs/design/v2-migration.md#브라우저-탭-제목과-파비콘).

Dated studies and prior decision text are preserved in [design history](https://github.com/naeil-dev/naeil-ui/blob/main/docs/design/history.md); they do not override these rules.
