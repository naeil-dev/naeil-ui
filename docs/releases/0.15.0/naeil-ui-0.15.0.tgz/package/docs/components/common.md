# Shared usage contract

These maintained guides describe the repository APIs; for the current published release, see [release identities and status](../package-release.md#publication-and-deployment). The [hosted Docs](https://naeil-dev.github.io/naeil-ui/) were last verified for [0.5.0 on 2026-10-15](https://github.com/naeil-dev/naeil-ui/releases/tag/v0.5.0), while `pnpm storybook` shows this checkout. Start with the [consumer setup and migration](../design/v2-migration.md). Primitives and generic Navigation/SiteFooter are exported from `@naeil/ui/ui`; the actual branded whole header uses the opt-in [NaeilHeader](naeil-header.md) entry `@naeil/ui/naeil-header`. Both are React-only. The legacy root needs the optional Next/next-intl peers. Examples import real wrappers; product state, validation and network requests belong to consumers.

Owned-service adoption uses [NaeilServiceShell with root NaeilThemeProvider](naeil-shell.md), `PageHeader` and the conformance CLI. The shell owns canonical header/main/footer, frame classes and theme policy; replace the old root theme provider. Standalone React uses `/naeil-shell`, provider-backed Next uses `/naeil-locale/chrome`. naeil.dev keeps its no-service catalog composition with the same root provider. Generic/legacy APIs below retain their supported overrides outside the protected shell contract.

## Styling, themes and overrides

Import `@naeil/ui/globals.css` once and register `@source` for the installed package's `dist` in your Tailwind 4 build. Alternatively load both theme.css and components.css alongside your existing Tailwind setup. Deliver Pretendard and, for Japanese, Noto Sans JP locally through your app's font pipeline; the package does not fetch fonts. Keep font OFL notices with redistributed binaries. The independent React example demonstrates consumer-owned delivery.

Root `.light`/`.dark` override OS theme; owned services let the shared provider manage these classes. Root `data-ui-density="compact"` changes spacing, not text size: default controls are 40px, compact 36px, small screens/coarse pointers at least 44px. Portals use document-level styles/density, so a locally themed subtree alone does not theme portaled content. Header, main and footer share a 1600px maximum outer frame and `clamp(16px, 2.4vw, 40px)` gutters. Generic/legacy compositions apply `ui-app-frame` to main; owned services receive it from the shell. Shared header/footer components apply their internal frame. Reading/settings sections remain capped at 640px, short forms at 480px, and lists at 1600px within the available frame space. Product root frame-token overrides remain supported for generic/legacy compositions; owned services do not restyle the shell through ancestors or reserved selectors. Explicit component classes remain available on APIs that support them. The [application layout guide](application-layout.md) explains composition, adoption and consistent overrides, including the 0.9.0 default stable root gutter, the coupled html opt-out and unchanged classic/overlay toolbar tokens. Theme-only/JS-only imports do not set document policy.

`className` is merged by `cn` (clsx + tailwind-merge). Consumer classes and primitive props remain available. Recheck specificity, text/control/focus contrast, mobile targets and portaled content after overriding. Override semantic color companions together; do not replace only an action hue or remove focus outlines. Reduced-motion rules remove shared transitions/animations. Custom consumer animation still needs its own reduced-motion treatment.

## Semantics and state ownership

Give every input/action a visible accessible name. Connect native labels with IDs, helper/error text with `aria-describedby`, invalid controls with `aria-invalid`, and async outcomes with an appropriate status/alert region. Placeholder is not a label. Preserve input on failure, give a recovery action, and enforce server validation in your application.

Loading is composition: state + meaningful text + `aria-busy`, with `disabled` when repeating the operation is invalid. Button has no `loading` prop. Static Card/Badge/Avatar do not gain loading/disabled/error behavior merely from an ARIA attribute. Use meaningful content and surrounding status messages. Native links are not disabled by a `disabled` prop forwarded through `asChild`.

Avoid nested buttons/links or embedding unrelated controls in a single clickable surface. A small Switch/Checkbox graphic has a 44px pseudo-element target; keep label rows at least 44px and leave room so adjacent targets do not overlap. Test actual pointer hit areas, keyboard focus and text wrapping in the consumer.

### Feedback and destructive color roles

Use `text-error` for error message text/icons, `bg-error-bg` for subtle error surfaces, and `border-error` for invalid boundaries. Reserve `destructive` / `destructive-foreground` for the filled background/foreground pair of a dangerous action (`Button variant="destructive"`) or destructive Badge.

Never use `text-destructive` (or destructive as text on canvas/card) for error copy: it fails normal-text contrast in dark mode (about 3.45:1 on the background, below 4.5:1). Use `text-error` instead.

## Long and localized content

Examples include Korean, English and Japanese. Set `lang` on translated content (Japanese selects Noto Sans JP in shared globals). Use responsive widths, `min-width: 0`, flexible heights and consumer wrapping classes for long actions/status text. The wrappers may use single-line truncation; retain the complete accessible name and offer the full value elsewhere if necessary. Do not shrink essential text to fit.

Run each affected composition under matching light/dark, comfortable/compact, mobile and long-content conditions. Check 320 CSS-pixel reflow, text scaling, CSS zoom and actual native browser zoom separately. Axe and keyboard automation do not replace assistive-technology use. Follow the [manual acceptance and support matrix](../design/public-ui-support.md) and [dated verification](../design/public-ui-stage3-verification.md).

[Field/choice composition](./composition.md) gives complete label/error and native-radio guidance. [Tabs](./tabs.md) and [Textarea](./textarea.md) extend the same shared contract; current extension results are in [Stage 4 verification](../design/public-ui-stage4-verification.md).

## Exact inherited contracts

Native wrappers use React 19 element props: inspect your installed `@types/react/index.d.ts`, or infer `React.ComponentProps<typeof Component>`. Radix wrappers use `React.ComponentProps<typeof Primitive.Part>`; inspect the installed declarations reached through `radix-ui/dist/index.d.ts`. Per-family guides link pinned declarations inspected locally during this work. Those links describe the inherited contract, not a promise that all primitive configurations have been tested. Wrapper defaults below are separate from primitive defaults; omitted primitive defaults are not invented here. Consumer examples and browser checks demonstrate only their recorded configuration.

## Theme and typography compatibility (2026-11-12)

The `dark:` variant in globals.css now follows the same conditions as generated dark tokens: `.dark` on an element or ancestor, plus OS dark under `:root:not(.light)` (including the root itself). Root `.light` opts out of OS dark; a deliberately nested `.dark` still opts into dark. Use only one root theme class. `.light` is a root OS opt-out, not a nested light-theme reset. Consumers composing theme.css + components.css with their own Tailwind entry must copy this variant into that entry to match the token contract:

```css
@custom-variant dark {
  &:where(.dark, .dark *) { @slot; }
  @media (prefers-color-scheme: dark) {
    &:where(:root:not(.light), :root:not(.light) *) { @slot; }
  }
}
```

Generated font-size utilities now include the approved line heights: `text-3xl` 32/42px, `text-xl` 20/29px, `text-base` 16/25px (UI body, component title and controls), `text-sm` 14/22px and `text-xs` 13/20px at a 16px root. Reading body uses `text-base leading-relaxed` (16/30px). PageTitle, DialogTitle and CardTitle no longer override their role line heights. This changes wrapping and vertical rhythm; recheck constrained layouts. Explicit consumer `leading-*` utilities remain supported. Numeric values live in typography.json; regenerate with `pnpm build:tokens`.
