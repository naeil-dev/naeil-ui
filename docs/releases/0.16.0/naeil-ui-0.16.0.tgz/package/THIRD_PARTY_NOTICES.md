# Third-party notices and provenance

Original repository software is MIT licensed. Upstream code and fonts retain their notices. Brand names/logos and assets with unknown provenance are not relicensed by the repository's MIT notice.

## Copied/adapted component code

Setup commit `8e614421eee6a1a3c6b148fe12d5af2b8446abab` explicitly records shadcn/ui and its Button. Commit `2965e3b976002056a1181305ea7b93543cf64f51` adds the eight-family customization (Avatar, Badge, Button, Card, Dialog, DropdownMenu, Input, Sonner). Current `src/components/ui/` files are customized descendants and newer Radix wrappers. No exact upstream registry revision was recorded; this notice does not invent one. Preserve the following shadcn notice when distributing adapted components.

Original license read 2026-10-02: https://github.com/shadcn-ui/ui/blob/main/LICENSE.md. It matches the installed shadcn package notice.

```text
MIT License

Copyright (c) 2023 shadcn

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Fonts

Shared package styles declare families; consumers own font delivery. The website imports Pretendard Variable from `pretendard`; Storybook imports Pretendard static CSS and `@fontsource/noto-sans-jp` 400/500/600. Both installed packages carry SIL Open Font License 1.1. Exact installed notices are preserved in [Pretendard](licenses/Pretendard-OFL.txt) and [Noto Sans JP](licenses/Noto-Sans-JP-OFL.txt). Keep the notice/license when redistributing font files; modified fonts must follow reserved-name rules.

Storybook 10.4.6 also bundles Nunito Sans for its manager interface. The original Google Fonts OFL body was read on 2026-10-02 and is preserved in [Nunito Sans](https://github.com/naeil-dev/naeil-ui/blob/main/licenses/Nunito-Sans-OFL.txt), including the original project-author notice; documentation preview output carries this notice as well. This manager font is Storybook tooling, not a new shared UI font choice.

The site's `src/app/layout.tsx` separately requests JetBrains Mono via `next/font/google`; no copied font binary is tracked here. Before redistributing fetched site-build fonts, retain the original license/notice supplied with that font (https://github.com/JetBrains/JetBrainsMono). This audit did not inspect the fetched Google font binary/license and does not certify a deployed site's font-notice bundle. Prototype HTML uses external CDNs separately from packed UI styles.

The naeil brand wordmark uses outlined Lato Regular 400 from Google Fonts commit `bd8f81ddb5c74d5c8897b36ad88b440266245103`, `ofl/lato/Lato-Regular.ttf`. The exact [Lato OFL 1.1 notice](licenses/Lato-OFL.txt) accompanies generated artwork in the package and Storybook. The independent brand kit retains the original font and source hashes; the UI package does not redistribute a runtime Lato font. Logo graphics do not become OFL-licensed font software, and naeil brand rights are separate from repository code licensing.

## Dependencies and references

The package also retains the [react-remove-scroll-bar MIT notice](licenses/react-remove-scroll-bar-MIT.txt) for consumer bundle notice generation. Storybook-only notices remain in the repository and documentation preview output.

Radix, Sonner, Lucide, React, Next.js and other npm dependencies carry licenses in their own distributions. They are not newly attributed as copied sources here; preserve their notices if bundling their code. DESIGN.md's Linear analysis is design reference material, not an official Linear specification or a component license. The optional workflow grants no blanket license to 21st catalog code; inspect each retrieved original before adoption.

## Website-only assets: unresolved provenance

`public/images/`, `public/svg/`, and `public/coral-concepts.html` contain brand/hero art. History records additions and normalization (`8252a3e`, `9a15ff0`, `e57c21c`) but does not establish each original artist, generation service, source license or redistribution permission. No such provenance is invented here. `public/next.svg`, `public/vercel.svg` and other starter SVGs entered during Next.js setup; logos remain the respective owners' marks. These assets are outside shared UI requirements and the current npm file allowlist. Establish their rights or replace them before a separate public asset/site redistribution claim. This unresolved site-art audit is not package release approval.

### Optional branded header candidate

Since 0.7.2, the branded header’s default naeil-ui catalog references one decorative image, https://naeil.dev/images/whale.png. It does not embed or redistribute those public/images bytes; their unresolved provenance above remains open. Site-adapter extraction does not establish artwork rights or clear unrelated website assets.
