import {createServer} from 'node:http';
import {readFileSync,mkdtempSync,existsSync,statSync} from 'node:fs';
import {join,resolve,extname} from 'node:path';
import {execFileSync,spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
const artifact=JSON.parse(readFileSync('/tmp/naeil-rollout-site-artifact.json'));
if(createHash('sha256').update(readFileSync(artifact.path)).digest('hex')!==artifact.sha256)throw Error('Site artifact digest mismatch');
const site=mkdtempSync('/tmp/naeil-site-immutable-');execFileSync('/usr/bin/tar',['-xzf',artifact.path,'-C',site]);
const child=spawn(process.execPath,[join(site,'server.js')],{cwd:site,stdio:'inherit',env:{PATH:process.env.PATH,NODE_ENV:'production',HOSTNAME:'localhost',PORT:'2480',NEXT_TELEMETRY_DISABLED:'1',NEXT_PUBLIC_SUPABASE_URL:'https://example.supabase.co',NEXT_PUBLIC_SUPABASE_ANON_KEY:'public-build-fixture'}});
const baby='/Users/jaymini/.local/share/naeil-ui-rollout/consumer-candidates/baby/a516d875a30fe7d4285df0a88c77b4531434f135/dist';
const types={'.html':'text/html','.js':'application/javascript','.css':'text/css','.woff2':'font/woff2','.woff':'font/woff','.svg':'image/svg+xml','.json':'application/json','.png':'image/png'};
const server=createServer((req,res)=>{
 const path=new URL(req.url,'http://127.0.0.1:2482').pathname;
 if(path.startsWith('/api/')){res.writeHead(404);return res.end();}
 const local=path==='/.well-known/naeil-ui.json'?'naeil-ui.json':path==='/dashboard/'?'index.html':path.startsWith('/dashboard/')?decodeURIComponent(path.slice(11)):null;
 const file=local?resolve(baby,local):null;
 if(!file||!file.startsWith(baby+'/')||!existsSync(file)||!statSync(file).isFile()){res.writeHead(404);return res.end();}
 res.writeHead(200,{'Content-Type':types[extname(file)]||'application/octet-stream','Cache-Control':'no-store','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https://naeil.dev/images/; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"});res.end(readFileSync(file));
});
server.listen(2482,'127.0.0.1',()=>console.log('Isolated immutable candidate servers: naeil2480, Baby2482. No API proxy.'));
let stopped=false;function close(){if(stopped)return;stopped=true;server.close();if(child.exitCode===null)child.kill('SIGTERM');}
process.on('SIGINT',close);process.on('SIGTERM',close);child.on('exit',()=>{server.close();});
