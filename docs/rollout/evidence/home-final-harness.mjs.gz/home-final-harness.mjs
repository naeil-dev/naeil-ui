import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFileSync,statSync,mkdirSync,writeFileSync} from 'node:fs';
import {join,extname,resolve,relative} from 'node:path';
import {pathToFileURL} from 'node:url';
import {chromium} from '@playwright/test';
import {readChrome,assertGeometry,assertLinks,checkMenu} from '../scripts/verify-ui-production.mjs';
import {verifyLocalCandidate} from '../scripts/verify-ui-candidate.mjs';
const frontend='/Users/jaymini/.paseo/worktrees/3qtenke4/shared-ui-rollout-home/frontend';
const dist=process.argv[2] || join(frontend,'dist');
const {createServer:createViteServer}=await import(pathToFileURL(join(frontend,'node_modules/vite/dist/node/index.js')));
globalThis.location=new URL('http://localhost');
const vite=await createViteServer({root:frontend,configFile:false,server:{middlewareMode:true},resolve:{alias:{'@':join(frontend,'src')}}});
const mocks=await vite.ssrLoadModule('/src/mocks/handlers.ts');
const {getResponse,http,HttpResponse}=await vite.ssrLoadModule('msw');
const handlers=[http.get('/api/openrouter-accounts',()=>HttpResponse.json({accounts:[]})),...mocks.handlers];
const server=createServer((req,res)=>{
 try {
  const path=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
  assert(!path.startsWith('/api/')&&!path.startsWith('/health'),'API request escaped synthetic browser interceptor');
  let file=join(dist,path);assert(!relative(dist,file).startsWith('..'));
  try {if(!statSync(file).isFile())file=join(dist,'index.html');}catch{if(extname(path))throw Error('missing asset');file=join(dist,'index.html');}
  res.setHeader('content-type',({'.js':'text/javascript','.css':'text/css','.json':'application/json','.woff2':'font/woff2','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon'})[extname(file)]||'text/html');res.end(readFileSync(file));
 }catch(e){res.writeHead(404);res.end('not found');}
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
const release=JSON.parse(readFileSync('docs/rollout/release.json'));release.archive.path=resolve('docs/rollout',release.archive.path);release.contract.path=resolve('docs/rollout',release.contract.path);
const reference=JSON.parse(readFileSync(release.contract.path));
const out=resolve('test-results/home-render');mkdirSync(out,{recursive:true});
async function configureContext(context,route){
 mocks.resetMockState({session:{authenticated:route.state!=='login',passwordConfigured:true,bootstrapRequired:false}});
 await context.addInitScript(({locale})=>{localStorage.setItem('codex-lb-language',locale);localStorage.setItem('codex-lb-theme',localStorage.getItem('theme')||'light');},{locale:route.locale});
 await context.route(url=>url.origin===origin&&(url.pathname.startsWith('/api/')||url.pathname.startsWith('/health')),async route=>{
  const req=route.request();const url=new URL(req.url());
  const result=await getResponse(handlers,new Request('http://localhost'+url.pathname+url.search,{method:req.method(),headers:req.headers(),body:req.postData()||undefined}));
  assert(result,'Unknown synthetic API '+url.pathname);
  await route.fulfill({status:result.status,headers:Object.fromEntries(result.headers),body:Buffer.from(await result.arrayBuffer())});
 });
}
async function preparePage(page,route){await page.locator('[data-naeil-footer]').waitFor();if(route.state==='login')await page.locator('input[type=password]').waitFor();else await page.locator('[data-slot=workspace]').waitFor();}
try{
 if(process.argv.includes('--final')){
  const identity=JSON.parse(readFileSync(join(dist,'.well-known/naeil-ui.json')));
  const routes=JSON.parse(readFileSync('docs/rollout/services.json')).services.find(s=>s.id==='home').routes;
  const result=await verifyLocalCandidate({release,origin,identity,routes,referencePath:release.contract.path,outputDir:out,configureContext,preparePage});console.log(JSON.stringify({routes:result.routes.length,conditions:result.routes.reduce((n,r)=>n+r.cases.length,0),passed:result.passed,output:out}));
 } else {
  const browser=await chromium.launch();const results=[];
  try {for(const width of [390,1440,1920])for(const theme of ['light','dark']){
   const context=await browser.newContext({viewport:{width,height:900},colorScheme:theme});await context.addInitScript(theme=>localStorage.setItem('theme',theme),theme);await configureContext(context,{locale:'ko',state:'dashboard'});
   const page=await context.newPage();page.on('requestfailed',r=>console.log('request-failed',r.url(),r.failure()?.errorText));page.on('console',m=>{if(m.type()==='error')console.log('browser-error',m.text());});await page.goto(origin);await preparePage(page,{state:'dashboard'});await page.waitForFunction(theme=>document.documentElement.classList.contains(theme),theme);const actual=await readChrome(page,'ko');
   const baseline=reference.cases.find(r=>r.locale==='ko'&&r.theme===theme&&r.width===width&&r.variant===actual.footerVariant);
   const errors=[];try{assertGeometry(actual,reference.contract,baseline.render);assertLinks(actual,'ko',origin,reference.contract);await checkMenu(page,'ko',theme,{themeControlLabels:{light:'테마',dark:'테마'}});}catch(e){errors.push(e.message);}
   await page.screenshot({path:join(out,`preview-${width}-${theme}.png`),fullPage:true});results.push({width,theme,actual,errors});await context.close();
  }} finally {await browser.close();}
  writeFileSync(join(out,'preview.json'),JSON.stringify(results,null,2));console.log(JSON.stringify(results.map(({width,theme,errors})=>({width,theme,errors}))));
 }
}finally{await vite.close();await new Promise(r=>server.close(r));}
