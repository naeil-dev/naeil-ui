import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {join} from 'node:path';
import {verifyProduction} from '../../scripts/verify-ui-production.mjs';
import {verifyIdentity} from '../../scripts/rollout/rollout.mjs';
const input=JSON.parse(readFileSync(new URL('./naeil-input.json',import.meta.url)));
const output=new URL('./naeil-by-route/',import.meta.url).pathname;mkdirSync(output,{recursive:true});
const results=[],failures=[];let next=0;
await verifyIdentity(input.origin,input.identity);
async function worker(){for(;;){const i=next++;if(i>=input.routes.length)return;try{const result=await verifyProduction({...input,routes:[input.routes[i]],outputDir:join(output,String(i))});results[i]=result;console.log(JSON.stringify({index:i,path:input.routes[i].path,passed:true,conditions:result.routes[0].cases.length}));}catch(error){failures.push({index:i,path:input.routes[i].path,message:error.message});console.error(JSON.stringify(failures.at(-1)));}}}
await Promise.all([worker(),worker(),worker()]);
writeFileSync(join(output,'attempt.json'),JSON.stringify({failures,completed:results.filter(Boolean).length,expected:input.routes.length},null,2));
assert.equal(failures.length,0,'Route failures retained in attempt.json; no automatic retry');
await verifyIdentity(input.origin,input.identity);
const report={schemaVersion:1,referenceSha256:results[0].referenceSha256,identity:input.identity,checkedAt:new Date().toISOString(),routes:results.flatMap(x=>x.routes),passed:true};
assert.equal(report.routes.length,31);assert.equal(report.routes.flatMap(x=>x.cases).length,248);
writeFileSync(join(output,'render-verification.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({passed:true,routes:report.routes.length,conditions:248}));
