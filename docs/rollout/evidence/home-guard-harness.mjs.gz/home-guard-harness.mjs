import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFileSync,statSync,mkdirSync,writeFileSync} from 'node:fs';
import {join,extname,resolve,relative} from 'node:path';
import {pathToFileURL} from 'node:url';
import {chromium} from '@playwright/test';
import {readChrome,assertGeometry,assertLinks,checkMenu} from '../scripts/verify-ui-production.mjs';
import {verifyLocalCandidate} from '../scripts/verify-ui-candidate.mjs';
const frontend='/Users/jaymini/.paseo/worktrees/3qtenke4/shared-ui-rollout-home/frontend';
const dist=process.argv[2] || join(frontend,'dist');
const {createServer:createViteServer}=await import(pathToFileURL(join(frontend,'node_modules/vite/dist/node/index.js')));
globalThis.location=new URL('http://localhost');
const vite=await createViteServer({root:frontend,configFile:false,server:{middlewareMode:true},resolve:{alias:{'@':join(frontend,'src')}}});
const mocks=await vite.ssrLoadModule('/src/mocks/handlers.ts');
const {getResponse,http,HttpResponse}=await vite.ssrLoadModule('msw');
const handlers=[http.get('/api/openrouter-accounts',()=>HttpResponse.json({accounts:[]})),...mocks.handlers];
const server=createServer((req,res)=>{
 try {
  const path=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
  assert(!path.startsWith('/api/')&&!path.startsWith('/health'),'API request escaped synthetic browser interceptor');
  let file=join(dist,path);assert(!relative(dist,file).startsWith('..'));
  try {if(!statSync(file).isFile())file=join(dist,'index.html');}catch{if(extname(path))throw Error('missing asset');file=join(dist,'index.html');}
  res.setHeader('content-type',({'.js':'text/javascript','.css':'text/css','.json':'application/json','.woff2':'font/woff2','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon'})[extname(file)]||'text/html');res.end(readFileSync(file));
 }catch(e){res.writeHead(404);res.end('not found');}
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
const release=JSON.parse(readFileSync('docs/rollout/release.json'));release.archive.path=resolve('docs/rollout',release.archive.path);release.contract.path=resolve('docs/rollout',release.contract.path);
const reference=JSON.parse(readFileSync(release.contract.path));
const out=resolve('test-results/home-render');mkdirSync(out,{recursive:true});
async function configureContext(context,route){
 mocks.resetMockState({session:{authenticated:route.state!=='login',passwordConfigured:true,bootstrapRequired:false}});
 await context.addInitScript(({locale})=>{localStorage.setItem('codex-lb-language',locale);localStorage.setItem('codex-lb-theme',localStorage.getItem('theme')||'light');},{locale:route.locale});
 await context.route(url=>url.origin===origin&&(url.pathname.startsWith('/api/')||url.pathname.startsWith('/health')),async route=>{
  const req=route.request();const url=new URL(req.url());
  const result=await getResponse(handlers,new Request('http://localhost'+url.pathname+url.search,{method:req.method(),headers:req.headers(),body:req.postData()||undefined}));
  assert(result,'Unknown synthetic API '+url.pathname);
  await route.fulfill({status:result.status,headers:Object.fromEntries(result.headers),body:Buffer.from(await result.arrayBuffer())});
 });
}
async function preparePage(page,route){await page.locator('[data-naeil-footer]').waitFor();if(route.state==='login')await page.locator('input[type=password]').waitFor();else await page.locator('[data-slot=workspace]').waitFor();}
try{
 const browser=await chromium.launch();const results=[];
 try {
  for(const status of [503,409,401]){
   const context=await browser.newContext({viewport:{width:1440,height:900}});await configureContext(context,{locale:'ko',state:'dashboard'});
   await context.route(url=>url.origin===origin&&url.pathname==='/api/settings',async route=>{
    if(route.request().method()!=='PUT')return route.fallback();
    await route.fulfill({status,contentType:'application/json',body:JSON.stringify({error:{code:status===409?'version_conflict':status===401?'unauthorized':'unavailable',message:'Synthetic save failure'}})});
   });
   const page=await context.newPage();page.setDefaultTimeout(10000);await page.goto(origin);await preparePage(page,{state:'dashboard'});
   await page.getByRole('button',{name:'설정',exact:true}).click();
   const radio=page.getByRole('radio',{name:/순환/});await radio.click();
   await page.keyboard.press('Escape');
   const dialog=page.getByRole('dialog',{name:'변경 사항을 버릴까요?',exact:true});await dialog.waitFor();
   await dialog.getByRole('button',{name:'저장하고 닫기',exact:true}).click();
   await page.waitForTimeout(300);
   await dialog.getByRole('button',{name:'계속 편집',exact:true}).click();
   assert(await radio.isChecked(),'Failed save lost draft');assert.equal(new URL(page.url()).pathname,'/');
   results.push({saveStatus:status,draftPreserved:true,routePreserved:true});await context.close();
  }
  const context=await browser.newContext({viewport:{width:1440,height:900}});await configureContext(context,{locale:'ko',state:'dashboard'});
  const page=await context.newPage();await page.goto(origin);await preparePage(page,{state:'dashboard'});
  await page.locator('[data-naeil-header] a[href="/keys"]').click();await page.waitForURL('**/keys');
  await page.locator('[data-naeil-header] a[href="/connections"]').click();await page.waitForURL('**/connections');
  await page.goBack();await page.waitForURL('**/keys');await page.goForward();await page.waitForURL('**/connections');
  results.push({clientNavigation:true,back:true,forward:true});await context.close();
  writeFileSync(join(out,'guard-browser.json'),JSON.stringify({scope:'local-synthetic-candidate',productionVerified:false,passed:true,results},null,2));console.log(JSON.stringify(results));
 }finally{await browser.close();}
}finally{await vite.close();await new Promise(r=>server.close(r));}
