import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {verifyLocalCandidate} from '/Users/jaymini/.paseo/worktrees/28nele6j/pure-chicken/scripts/verify-ui-candidate.mjs';
const release=JSON.parse(readFileSync('/tmp/naeil-rollout-release.json'));
const base='/Users/jaymini/.local/share/naeil-ui-rollout/comparisons/3b13e95';mkdirSync(base,{recursive:true});
const siteArtifact=JSON.parse(readFileSync('/tmp/naeil-rollout-site-artifact.json'));
const identity={schemaVersion:1,appId:'naeil',artifactId:siteArtifact.id,sourceRevision:siteArtifact.sourceRevision,ui:siteArtifact.ui};
const routes=['en','ko','ja'].flatMap(locale=>['/projects','/baby-agent','/pkm','/sa','/cc'].map(path=>({path:`${locale==='en'?'':'/'+locale}${path}` || '/',locale,policy:'canonical'})));
const site=await verifyLocalCandidate({release,origin:'http://localhost:2480',identity,routes,referencePath:release.contract.path,outputDir:`${base}/naeil-additional`});
console.log(`Naeil local candidate: ${site.routes.length} routes / ${site.routes.reduce((n,r)=>n+r.cases.length,0)} conditions passed.`);
