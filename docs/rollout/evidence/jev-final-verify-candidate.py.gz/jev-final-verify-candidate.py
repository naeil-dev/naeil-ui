from pathlib import Path
import hashlib, json, os, subprocess, sys, tarfile

root = Path(sys.argv[1]).resolve()
receipt = json.loads((root / 'receipt.json').read_text())
manifest_bytes = (root / 'file-manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
tree = root / 'standalone'
hash_bytes = lambda data: hashlib.sha256(data).hexdigest()
actual = {str(path.relative_to(tree)) for path in tree.rglob('*') if path.is_file() or path.is_symlink()}
assert actual == set(manifest), 'Runtime members changed'
regular_files = {name: entry for name, entry in manifest.items() if entry.get('type') != 'symlink'}
links = {name: entry for name, entry in manifest.items() if entry.get('type') == 'symlink'}
assert len(regular_files) == receipt['fileCount']
assert len(links) == receipt.get('linkCount', 0)
assert len(manifest) == receipt.get('manifestEntryCount', len(manifest))
for name, expected in manifest.items():
    path = tree / name
    if expected.get('type') == 'symlink':
        assert path.is_symlink() and os.readlink(path) == expected['target'], name
        assert not Path(expected['target']).is_absolute(), name
        target = path.resolve(strict=True)
        assert target.is_relative_to(tree), name
        assert str(target.relative_to(tree)) == expected['resolvedTarget'], name
    else:
        assert path.is_file() and not path.is_symlink(), name
        data = path.read_bytes()
        assert len(data) == expected['bytes'] and hash_bytes(data) == expected['sha256'], name
assert receipt['contentId'] == 'sha256-' + hash_bytes(manifest_bytes)
source_bytes = (root / 'source.tar').read_bytes()
assert hash_bytes(source_bytes) == receipt['sourceArchiveSha256']
source_commit = subprocess.check_output(['git', 'get-tar-commit-id'], input=source_bytes).decode().strip()
assert source_commit == receipt['sourceRevision']
with tarfile.open(root / 'source.tar') as archive:
    assert hash_bytes(archive.extractfile('pnpm-lock.yaml').read()) == receipt['lockSha256']
    assert hash_bytes(archive.extractfile('vendor/naeil-ui-0.7.0.tgz').read()) == receipt['packageSha256']
assert hash_bytes((root / 'standalone.tar.gz').read_bytes()) == receipt['standaloneArchiveSha256']
with tarfile.open(root / 'standalone.tar.gz') as archive:
    entries = [entry for entry in archive.getmembers() if entry.isfile() or entry.issym()]
    assert all(entry.isfile() or entry.issym() or entry.isdir() for entry in archive.getmembers()), 'Unexpected tar member type'
    assert len(entries) == len(manifest)
    names = [entry.name.removeprefix('standalone/') for entry in entries]
    assert len(set(names)) == len(names) and set(names) == set(manifest)
    for entry, name in zip(entries, names):
        expected = manifest[name]
        if expected.get('type') == 'symlink':
            assert entry.issym() and entry.linkname == expected['target'], name
        else:
            assert entry.isfile(), name
            data = archive.extractfile(entry).read()
            assert len(data) == expected['bytes'] and hash_bytes(data) == expected['sha256'], name
    assert not any(Path(name).name.startswith('._') for name in names)
assert not any(Path(name).name in {'.env', 'server.env', 'password.json', 'state.sqlite', 'api-key', 'coral.png', 'fish.png', 'jellyfish.png', 'turtle.png', 'whale.png'} or name.startswith('tests/fixtures/') for name in manifest)
identity = json.loads((tree / 'public/.well-known/naeil-ui.json').read_text())
assert identity == {key: receipt[key] for key in ['schemaVersion', 'appId', 'artifactId', 'sourceRevision', 'ui']}
assert (tree / '.next/BUILD_ID').read_text().strip() == receipt['buildId']
print(json.dumps({'sourceRevision': source_commit, 'artifactId': receipt['artifactId'], 'contentId': receipt['contentId'], 'runtimeFilesVerified': len(regular_files), 'runtimeLinksVerified': len(links), 'tarFilesVerified': sum(entry.isfile() for entry in entries), 'tarLinksVerified': sum(entry.issym() for entry in entries), 'linksBoundToArtifact': True, 'sourceArchiveVerified': True, 'sourceArchiveCommitMatched': True, 'archiveLockAndPackageMatched': True, 'identityMatched': True, 'metadataSidecars': 0, 'runtimeUnchanged': True}, indent=2))
