import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { chromium, expect } from '@playwright/test';

// Run with: node --test scripts/site-auth-slot.test.mjs (Chromium installed).
const require = createRequire(import.meta.url);
const { build } = require(require.resolve('esbuild', { paths: [require.resolve('tsup')] }));
// Keep the real website adapter, shared header, responsive Navigation and Radix
// menus. Only framework routing/i18n and the external session request are fakes.
const mocks = {
  'next-intl': `export const useLocale = () => 'ja';
    export const useTranslations = () => key => key;`,
  'next/navigation': `export { unstable_rethrow } from 'next/dist/client/components/unstable-rethrow.browser';`,
  '@/i18n/routing': `import {createElement} from 'react';
    export const Link = props => createElement('a', props);
    export const usePathname = () => '/editor';
    export const useRouter = () => ({replace() {}});`,
  '@/app/[locale]/login/actions': `export function logout(locale) {
    window.siteFixture.requests.push(locale);
    return new Promise((resolve, reject) => { window.siteFixture.finish = error => error ? reject(error) : resolve(); });
  }`,
  sonner: `export const toast = {error: message => window.siteFixture.errors.push(message)};`,
};
const output = await build({
  stdin: { contents: `import {createElement} from 'react';
    import {createRoot} from 'react-dom/client';
    import {NavWrapper} from './src/components/nav-wrapper';
    window.siteFixture = {requests: [], errors: []};
    createRoot(document.getElementById('root')).render(createElement(NavWrapper, {user: {id: 'synthetic-user'}}));`,
    resolveDir: process.cwd(), loader: 'tsx' },
  bundle: true, write: false, format: 'iife', platform: 'browser', jsx: 'automatic',
  define: { 'process.env.NODE_ENV': '"production"' },
  plugins: [{ name: 'website-boundaries', setup(builder) {
    builder.onResolve({ filter: /^(next-intl|next\/navigation|sonner|@\/i18n\/routing|@\/app\/)/ }, args =>
      Object.hasOwn(mocks, args.path) ? { path: args.path, namespace: 'website-test' } : undefined);
    builder.onLoad({ filter: /.*/, namespace: 'website-test' }, args => ({ contents: mocks[args.path], resolveDir: process.cwd(), loader: 'js' }));
  } }],
});
const { readdirSync, writeFileSync } = await import('node:fs');
const { join } = await import('node:path');
const { captureAccountRender, assertAccountRender } = await import('../../scripts/account-render.mjs');
const root = process.cwd();
const reference = JSON.parse(readFileSync(join(root, 'docs/rollout/frozen/naeil-account-0.7.1.json')));
const cssFiles = readdirSync(join(root, '.next/static/chunks')).filter(name => name.endsWith('.css'));
const browser = await chromium.launch();
const results = [];
try {
 for (const width of [390,1440]) for (const theme of ['light','dark']) {
  const page = await browser.newPage({viewport:{width,height:900},colorScheme:theme});
  await page.route('**/*', async route => {
   const url = new URL(route.request().url());
   if (url.origin !== 'http://site-fixture.invalid') return route.abort();
   if (url.pathname === '/') return route.fulfill({contentType:'text/html',body:`<!doctype html><html lang="ja" class="${theme}"><head>${cssFiles.map(name=>`<link rel="stylesheet" href="/_next/static/chunks/${name}">`).join('')}</head><body><div id="root"></div></body></html>`});
   if (url.pathname.startsWith('/_next/static/')) {
    const relative = url.pathname.slice('/_next/static/'.length);
    assert(!relative.includes('..'));
    return route.fulfill({path:join(root,'.next/static',relative)});
   }
   return route.abort();
  });
  await page.goto('http://site-fixture.invalid/');
  await page.addScriptTag({content:output.outputFiles[0].text});
  await expect(page.locator('[data-naeil-header]')).toBeVisible();
  assert((await page.evaluate(()=>document.fonts.load('500 16px "Noto Sans JP"','アカウントログアウト').then(f=>f.length)))>0);
  if(width===390) await page.getByRole('button',{name:'メニュー',exact:true}).click();
  await page.locator('[data-naeil-account-trigger]:visible').click();
  const actual=await captureAccountRender(page);
  const sample=reference.cases.find(c=>c.width===width&&c.theme===theme);
  assertAccountRender(actual,sample.render);
  await page.screenshot({path:join(root,'test-results/account-site',`site-ja-${width}-${theme}.png`),animations:'disabled'});
  results.push({width,theme,locale:'ja',render:actual,passed:true});
  await page.close();
 }
 writeFileSync(join(root,'test-results/account-site/render.json'),JSON.stringify({sourceRevision:'805b7197520b292d126c0194e4d09a2073ade975',scope:'Real site NavWrapper and freshly compiled site CSS/static fonts; session and routing boundaries mocked. No protected production access.',reference:'naeil-account-0.7.1.json',cases:results,passed:true},null,2));
 console.log(`${results.length} actual site-adapter/compiled-CSS account references passed`);
} finally {await browser.close();}
