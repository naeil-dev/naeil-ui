import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFileSync,statSync,mkdirSync,writeFileSync} from 'node:fs';
import {join,extname,resolve,relative} from 'node:path';
import {pathToFileURL} from 'node:url';
import {chromium} from '@playwright/test';
import {readChrome,assertGeometry,assertLinks,checkMenu} from '../scripts/verify-ui-production.mjs';
import {verifyLocalCandidate} from '../scripts/verify-ui-candidate.mjs';
const frontend='/Users/jaymini/.paseo/worktrees/3qtenke4/shared-ui-rollout-home/frontend';
const dist=process.argv[2] || join(frontend,'dist');
const {createServer:createViteServer}=await import(pathToFileURL(join(frontend,'node_modules/vite/dist/node/index.js')));
globalThis.location=new URL('http://localhost');
const vite=await createViteServer({root:frontend,configFile:false,server:{middlewareMode:true},resolve:{alias:{'@':join(frontend,'src')}}});
const mocks=await vite.ssrLoadModule('/src/mocks/handlers.ts');
const {getResponse,http,HttpResponse}=await vite.ssrLoadModule('msw');
const handlers=[http.get('/api/openrouter-accounts',()=>HttpResponse.json({accounts:[]})),...mocks.handlers];
const server=createServer((req,res)=>{
 try {
  const path=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
  assert(!path.startsWith('/api/')&&!path.startsWith('/health'),'API request escaped synthetic browser interceptor');
  let file=join(dist,path);assert(!relative(dist,file).startsWith('..'));
  try {if(!statSync(file).isFile())file=join(dist,'index.html');}catch{if(extname(path))throw Error('missing asset');file=join(dist,'index.html');}
  res.setHeader('content-type',({'.js':'text/javascript','.css':'text/css','.json':'application/json','.woff2':'font/woff2','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon'})[extname(file)]||'text/html');res.end(readFileSync(file));
 }catch(e){res.writeHead(404);res.end('not found');}
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
const release=JSON.parse(readFileSync('docs/rollout/release.json'));release.archive.path=resolve('docs/rollout',release.archive.path);release.contract.path=resolve('docs/rollout',release.contract.path);
const reference=JSON.parse(readFileSync(release.contract.path));
const out=resolve('test-results/home-render');mkdirSync(out,{recursive:true});
async function configureContext(context,route){
 mocks.resetMockState({session:{authenticated:route.state!=='login',passwordConfigured:true,bootstrapRequired:false}});
 await context.addInitScript(({locale})=>{localStorage.setItem('codex-lb-language',locale);localStorage.setItem('codex-lb-theme',localStorage.getItem('theme')||'light');},{locale:route.locale});
 await context.route(url=>url.origin===origin&&(url.pathname.startsWith('/api/')||url.pathname.startsWith('/health')),async route=>{
  const req=route.request();const url=new URL(req.url());
  const result=await getResponse(handlers,new Request('http://localhost'+url.pathname+url.search,{method:req.method(),headers:req.headers(),body:req.postData()||undefined}));
  assert(result,'Unknown synthetic API '+url.pathname);
  await route.fulfill({status:result.status,headers:Object.fromEntries(result.headers),body:Buffer.from(await result.arrayBuffer())});
 });
}
async function preparePage(page,route){await page.locator('[data-naeil-footer]').waitFor();if(route.state==='login')await page.locator('input[type=password]').waitFor();else await page.locator('[data-slot=workspace]').waitFor();}
try{
 const browser=await chromium.launch();
 try {
  const context=await browser.newContext({viewport:{width:390,height:900}});await configureContext(context,{locale:'ko',state:'dashboard'});
  const page=await context.newPage();await page.goto(origin);await preparePage(page,{state:'dashboard'});
  await page.keyboard.press('Tab');
  const skip=await page.locator('a[href="#main"]').evaluate(el=>{const b=el.getBoundingClientRect();return {focused:el===document.activeElement,visibleAtCenter:el.contains(document.elementFromPoint(b.x+b.width/2,b.y+b.height/2)),z:getComputedStyle(el).zIndex};});
  await page.screenshot({path:join(out,'skip-link-after.png')});
  await page.getByRole('button',{name:'메뉴',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'로그아웃',exact:true}).click();
  await page.locator('input[type=password]').waitFor({state:'attached'});await page.waitForTimeout(300);
  const logout={menuVisible:await page.getByRole('dialog',{name:'메뉴',exact:true}).isVisible(),passwordVisible:await page.locator('input[type=password]').isVisible()};
  assert(skip.focused && skip.visibleAtCenter && !logout.menuVisible && logout.passwordVisible);
  console.log(JSON.stringify({skip,logout,passed:true}));
  await page.screenshot({path:join(out,'mobile-logout-after.png')});
 }finally{await browser.close();}
}finally{await vite.close();await new Promise(r=>server.close(r));}
