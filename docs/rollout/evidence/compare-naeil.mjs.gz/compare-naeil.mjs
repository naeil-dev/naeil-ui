import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {verifyLocalCandidate} from '/Users/jaymini/.paseo/worktrees/28nele6j/pure-chicken/scripts/verify-ui-candidate.mjs';
const release=JSON.parse(readFileSync('/tmp/naeil-rollout-release.json'));
const base='/Users/jaymini/.local/share/naeil-ui-rollout/comparisons/3b13e95';mkdirSync(base,{recursive:true});
const siteArtifact=JSON.parse(readFileSync('/tmp/naeil-rollout-site-artifact.json'));
const identity={schemaVersion:1,appId:'naeil',artifactId:siteArtifact.id,sourceRevision:siteArtifact.sourceRevision,ui:siteArtifact.ui};
const routes=['en','ko','ja'].flatMap(locale=>['','/login','/design','/blog','/blog/2026-03-30'].map(path=>({path:`${locale==='en'?'':'/'+locale}${path}` || '/',locale,policy:'canonical'})));
const site=await verifyLocalCandidate({release,origin:'http://localhost:2480',identity,routes,referencePath:release.contract.path,outputDir:`${base}/naeil`});
console.log(`Naeil local candidate: ${site.routes.length} routes / ${site.routes.reduce((n,r)=>n+r.cases.length,0)} conditions passed.`);
const babyIdentity=JSON.parse(readFileSync('/Users/jaymini/.local/share/naeil-ui-rollout/consumer-candidates/baby/a516d875a30fe7d4285df0a88c77b4531434f135/dist/naeil-ui.json'));
const baby=await verifyLocalCandidate({release,origin:'http://127.0.0.1:2482',identity:babyIdentity,routes:['login','dashboard'].map(state=>({path:'/dashboard/',state,locale:'ko',policy:'canonical'})),referencePath:release.contract.path,outputDir:`${base}/baby`,
 configureContext:async context=>{await context.route('**/api/v1/**',async route=>{
  const path=new URL(route.request().url()).pathname;
  const json=path==='/api/v1/auth/pin'?{token:'synthetic-test-token'}:path==='/api/v1/summary/daily'?{days:[]}:path==='/api/v1/summary/hourly'?{hours:[]}:path==='/api/v1/vaccinations'?{vaccinations:[],summary:{completed:0,total:0,due:0}}:['/api/v1/feeding','/api/v1/growth'].includes(path)?{events:[],total_count:0}:null;
  if(json===null)throw Error(`Unregistered synthetic route ${path}`);await route.fulfill({json});
 });},preparePage:async(page,route)=>{if(route.state==='dashboard'){await page.getByLabel('PIN',{exact:true}).fill('1234');await page.getByRole('button',{name:'로그인',exact:true}).click();await page.getByRole('heading',{name:/Baby Dashboard/}).waitFor();}}
});
console.log(`Baby local candidate: ${baby.routes.length} states / ${baby.routes.reduce((n,r)=>n+r.cases.length,0)} conditions passed.`);
writeFileSync(`${base}/summary.json`,JSON.stringify({scope:'local-synthetic-candidate',productionVerified:false,naeil:{routes:site.routes.length,conditions:120},baby:{states:2,conditions:16}},null,2));
