import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createConnection} from 'node:net';
import {openSync,closeSync,readFileSync,mkdirSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {verifyLocalCandidate} from '../scripts/verify-ui-candidate.mjs';
import {assertRouteState} from '../scripts/verify-ui-production.mjs';
const workspace='/Users/jaymini/.paseo/worktrees/3tl6a87q/shared-ui-rollout-jev';
const candidate=resolve(process.argv[2]);
const origin='http://127.0.0.1:2467';
const occupied=await new Promise(resolve=>{const s=createConnection({host:'127.0.0.1',port:2467});s.once('connect',()=>{s.destroy();resolve(true)});s.once('error',()=>resolve(false));});
assert(!occupied,'2467 is occupied; no existing process will be stopped');
const out=resolve('test-results/jev-render');mkdirSync(out,{recursive:true});
const log=openSync(join(out,'synthetic-server.log'),'w');
const server=spawn(process.execPath,[join(workspace,'tests/fixtures/start-server.mjs')],{cwd:workspace,env:{...process.env,JEV_TEST_STANDALONE:join(candidate,'standalone')},stdio:['ignore',log,log]});
const exited=new Promise(r=>server.once('exit',r));
try {
 let ready=false;
 for(let i=0;i<150;i++){try{const r=await fetch(origin+'/.well-known/naeil-ui.json');if(r.ok){ready=true;break;}}catch{} if(server.exitCode!==null)break;await new Promise(r=>setTimeout(r,200));}
 assert(ready,'Synthetic standalone did not start');
 const release=JSON.parse(readFileSync('docs/rollout/release.json'));release.archive.path=resolve('docs/rollout',release.archive.path);release.contract.path=resolve('docs/rollout',release.contract.path);
 const identity=JSON.parse(readFileSync(join(candidate,'standalone/public/.well-known/naeil-ui.json')));
 const routes=JSON.parse(readFileSync('docs/rollout/services.json')).services.find(s=>s.id==='jev').routes;
 const result=await verifyLocalCandidate({release,origin,identity,routes,referencePath:release.contract.path,outputDir:out,
  async configureContext(context,route){
   if(route.state!=='login'){
    const r=await context.request.post(origin+'/api/login',{headers:{origin},data:{password:'demo-test-only'}});assert.equal(r.status(),200,'Synthetic auth failed');
   }
  },
  async preparePage(page,route){await page.locator('#main[data-locale-ready=true]').waitFor();await assertRouteState(page,route);}
 });
 console.log(JSON.stringify({passed:result.passed,conditions:result.routes.reduce((n,r)=>n+r.cases.length,0),identity,output:out}));
} finally {
 if(server.exitCode===null)server.kill('SIGTERM');await exited;closeSync(log);
}
